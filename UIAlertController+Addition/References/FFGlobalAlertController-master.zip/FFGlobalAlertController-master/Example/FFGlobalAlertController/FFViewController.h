//
//  FFViewController.h
//  FFGlobalAlertController
//
//  Created by Eric Larson on 06/18/2015.
//  Copyright (c) 2015 ForeFlight. All rights reserved.
//

@import UIKit;

@interface FFViewController : UIViewController

@end
