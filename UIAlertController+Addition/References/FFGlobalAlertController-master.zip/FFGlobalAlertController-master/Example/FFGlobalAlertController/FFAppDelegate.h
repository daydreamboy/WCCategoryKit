//
//  FFAppDelegate.h
//  FFGlobalAlertController
//
//  Created by CocoaPods on 06/18/2015.
//  Copyright (c) 2014 Eric Larson. All rights reserved.
//

@import UIKit;

@interface FFAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
